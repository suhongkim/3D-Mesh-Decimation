# 3D_Mesh_Decimation
Quadric-based Mesh Decimation Via Multiple Choices Algorithm

Hi, 

I submitted it yesterday, but I updated little. 

I still sometimes have a segmentation error, which I don't know anymore... 
But, if you try with small decimation, it works. 


Thank you so much for your support. 

Best regards, 

SUhong Kim 
