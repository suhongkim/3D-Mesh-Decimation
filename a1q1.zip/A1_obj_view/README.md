# NanoGUI Test

Hi Wallace. 

I've done everything in the problems. 
I checked this probram is working before submitting, but I don't know why it sometimes gives me an stack smeshing errors which I don't know why. 
So, if you cannot open the window or something looks wrong related to stack smeshing, Please let me know. 

Thank you for your help. 

Best, 

Suhong Kim 
